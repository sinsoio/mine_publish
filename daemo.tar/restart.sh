#$/bin/bash

kill -2 $(ps -ef | grep sinso | grep -v grep | awk '{print $2}')
while true
do
    ret=$(ps -ef | grep sinso | grep -v grep)
    if [ "$ret" == "" ]
    then
        nohup sinso start --config /data/nodes/node001/config.yaml 2>&1 &
        exit 0
    fi
    sleep 1
done
