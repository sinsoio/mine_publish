#$/bin/bash

kill -2 $(ps -ef | grep sinso | grep -v grep | awk '{print $2}')
