#$/bin/bash

nohup sinso start --config /data/nodes/node001/config.yaml 2>&1 &


