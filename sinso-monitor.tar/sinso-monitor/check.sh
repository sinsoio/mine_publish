#!/bin/bash

miner=$(cat ../node001/keys/sinso.key | awk -F "\"" '{print $4}')

node ./index.js $miner >> running.log