import Web3 from 'web3'
import { Transaction as Tx } from 'ethereumjs-tx'
import {spawn} from 'child_process'

const abi = [{
    "inputs": [
      {
        "internalType": "address",
        "name": "miner",
        "type": "address"
      }
    ],
    "name": "getMinerInfo",
    "outputs": [
      {
        "internalType": "enum ERoleType",
        "name": "role",
        "type": "uint8"
      },
      {
        "internalType": "bool",
        "name": "isOnline",
        "type": "bool"
      },
      {
        "internalType": "uint256",
        "name": "deposits",
        "type": "uint256"
      },
      {
        "internalType": "uint256",
        "name": "awards",
        "type": "uint256"
      },
      {
        "internalType": "uint256",
        "name": "withdrawn",
        "type": "uint256"
      },
      {
        "internalType": "uint256",
        "name": "locked",
        "type": "uint256"
      },
      {
        "internalType": "uint256",
        "name": "cashable",
        "type": "uint256"
      },
      {
        "internalType": "uint256",
        "name": "lastReport",
        "type": "uint256"
      },
      {
        "internalType": "uint256",
        "name": "lastClaim",
        "type": "uint256"
      },
      {
        "internalType": "address",
        "name": "minerContract",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "associates",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  }]
const address = '0xB9819d821b28EA78379E9b46E88b911Faf64EC65'
const web3 = new Web3()
web3.setProvider(new Web3.providers.HttpProvider("https://mainnet-rpc.amstarscan.com/"))
const sinso = new web3.eth.Contract(abi, address)

async function getMinerInfo(miner) {
    var isOnline, lastReport
    await sinso.methods.getMinerInfo(miner).call(function(error, result) {
        isOnline = result.isOnline
        lastReport= result.lastReport
    });
    return {isOnline, lastReport}
}

function resetSinso() {
    const reset = spawn('systemctl', ['reload', 'sinso.service']);
    // const reset = spawn('ls',['-l']);
    reset.on('close', (code)=>{
        console.log(`exit code: ${code}`);
    });
    console.log("reset")
}

var info = await getMinerInfo(process.argv[2])
var nowTime = Math.floor(Date.now()/1000)
console.log(nowTime, info)
// No report was reported within 30 minutes
var nextReportTime = info.lastReport + 3600
if (nowTime > nextReportTime && nowTime - nextReportTime > 1800 || false == info.isOnline) {
    resetSinso()
}
